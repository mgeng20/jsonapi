import json
from jsonapi import jsonapi

# Your custom JSON encoder and decoder code here...

# Sample data
data = {
    "integer": 42,
    "string": "Hello, World!",
    "complex": 3 + 4j,
    "list": [1, 2, 3],
    "nested": {
        "key1": "value1",
        "key2": "value2"
    }
}

# Serialize the data using your custom encoder
serialized_data = my_dumps(data, indent=2)

# Deserialize the data using your custom decoder
deserialized_data = my_loads(serialized_data)

# Compare the original data and deserialized data
print("Original data:")
print(data)
print("\nSerialized data:")
print(serialized_data)
print("\nDeserialized data:")
print(deserialized_data)

# Check if the deserialized data matches the original data
assert data == deserialized_data, "Deserialized data doesn't match the original data"
print("\nSerialization and deserialization were successful!")
